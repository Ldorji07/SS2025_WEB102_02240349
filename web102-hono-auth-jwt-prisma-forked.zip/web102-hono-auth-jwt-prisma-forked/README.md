To install dependencies:
```sh
bun install
```

To run:
```sh
bun run dev
```

open http://localhost:3000

# Hono Auth API with JWT & Prisma

## 🧩 Overview

This project is a backend authentication API built with **Hono**, a lightweight web framework, using **JWT** for secure token-based authentication and **Prisma ORM** for database access. It provides a clean and scalable foundation for handling user registration, login, token validation, and protected routes.

> 🔐 This version is forked and extended from a template to include improved structure and Prisma-based persistence.

---

## 🚀 Features

- User registration and login via email/password
- JWT access and refresh tokens
- Middleware-protected routes
- Prisma ORM for database modeling
- Secure password hashing (bcrypt)
- `.env` support for environment configuration
- Basic folder structure with modular routes and services

---

## 📁 Project Structure

