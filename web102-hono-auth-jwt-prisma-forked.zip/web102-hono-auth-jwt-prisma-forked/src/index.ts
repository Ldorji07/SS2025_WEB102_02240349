import { Hono } from "hono";
import { cors } from "hono/cors";
import { PrismaClient } from "@prisma/client";
import { HTTPException } from "hono/http-exception";
import { decode, sign, verify } from 'hono/jwt'
import { jwt } from 'hono/jwt'
import type { JwtVariables } from 'hono/jwt'

type Variables = JwtVariables

const app = new Hono<{ Variables: Variables }>()
const prisma = new PrismaClient();

// Enable CORS for all routes
app.use("/*", cors());

app.use(
  "/protected/*",
  jwt({
    secret: 'mySecretKey',
  })
);
app.get("/protected/account/balance", async (c) => {
  const payload = c.get('jwtPayload')
  if (!payload) {
    throw new HTTPException(401, { message: "Unauthorized" });
  }
  const user = await prisma.user.findUnique({
    where: { id: payload.sub },
    select: { Account: { select: { balance: true, id: true } } },
  });

  return c.json({ data: user });
});

app.get("/:userId/account/balance", async (c) => {
  const { userId } = c.req.param();

  // fetch user account data 
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { Account: { select: { balance: true, id: true } } },
  });

  return c.json({ data: user });
});

app.post("/register", async (c) => {
  try {
    const body = await c.req.json();

    const bcryptHash = await Bun.password.hash(body.password, {
      algorithm: "bcrypt",
      cost: 4, // number between 4-31
    });

    const user = await prisma.user.create({
      data: {
        email: body.email,
        hashPassword: bcryptHash,
        Account: {
          create: {
            balance: 0,
          },
        },
      },
    });

    return c.json({ message: `${user.email} created successfully}` });
  } catch (error) {
    return c.json({ error: error });
  }
});

app.post("/login", async (c) => {
  try {
    const body = await c.req.json();

    const user = await prisma.user.findUnique({
      where: { email: body.email },
      select: { id: true, hashPassword: true },
    });

    if (!user) {
      return c.json({ message: "User not found" });
    }

    const match = await Bun.password.verify(
      body.password,
      user.hashPassword,
      "bcrypt"
    );

    if (match) {
      const payload = {
        sub: user.id,
        exp: Math.floor(Date.now() / 1000) + 60 * 60, // Token expires in 60 minutes
      };
      const secret = "mySecretKey";
      const token = await sign(payload, secret);
      return c.json({ message: "Login successful", token: token });
    } else {
      throw new HTTPException(401, { message: "Invalid credentials" });
    }
  } catch (error) {
    throw new HTTPException(401, { message: 'Invalid credentials' })
  }
});

export default app;