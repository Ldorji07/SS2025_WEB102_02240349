
---

### ✅ `Reflection.md`

```markdown
# Reflection – Hono Auth API with JWT & Prisma

## 📄 Documentation

### Key Concepts Applied

- **JWT Authentication**: Implemented secure stateless user sessions using JSON Web Tokens. Access and refresh tokens are generated on login and verified through middleware.
- **Prisma ORM**: Used Prisma to define the user model, handle database migrations, and interact with PostgreSQL.
- **Middleware**: Developed a middleware for verifying JWT tokens on protected routes.
- **Hono Framework**: Leveraged Hono for a clean, minimalistic web API design with excellent performance.

---

## 💭 Reflection

### What I Learned

This project taught me how to combine modern web technologies like **Hono**, **Prisma**, and **JWT** into a cohesive backend system. I learned how to:

- Structure a scalable API with routes, middleware, and services
- Store and validate user sessions securely using tokens
- Model users and persist data using Prisma’s powerful schema system
- Handle sensitive information using `.env` configuration

---

### Challenges Faced

#### 1. **Token Expiry Configuration**
- ❌ At first, tokens never expired because I omitted the expiration setting.
- ✅ I updated the JWT payload to include an `exp` field and adjusted middleware to reject expired tokens.

#### 2. **Prisma Errors During Migration**
- ❌ Prisma migrations failed due to an incorrect DATABASE_URL format.
- ✅ I fixed the URL in `.env`, dropped the database, and re-applied the migration.

#### 3. **Route Access Issues**
- ❌ Protected routes were not rejecting unauthorized access.
- ✅ I traced the issue to a missing middleware import and added it to the route definition.

---

## ✅ Conclusion

Forking this project gave me a deeper understanding of how authentication flows work in real-world apps. I now feel more confident building secure APIs with modern tools like Hono and Prisma. This project also reinforced the importance of error handling, token management, and middleware in building production-ready APIs.
